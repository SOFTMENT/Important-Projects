package com.svenska.DealsCutter.Interface;

public interface RefreshCall {
    public void refresh();
}
