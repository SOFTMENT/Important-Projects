package com.softmentclient.Bikoose.Interface;

public interface RefreshCall {
    public void refresh();
}
