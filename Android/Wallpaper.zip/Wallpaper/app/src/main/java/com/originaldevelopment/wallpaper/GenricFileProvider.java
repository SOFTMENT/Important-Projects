package com.originaldevelopment.wallpaper;

import androidx.core.content.FileProvider;

public class GenricFileProvider extends FileProvider {}