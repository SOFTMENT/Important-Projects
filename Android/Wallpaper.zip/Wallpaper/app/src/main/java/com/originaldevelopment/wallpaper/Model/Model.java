package com.originaldevelopment.wallpaper.Model;


public class Model  {

    private int image;


    public Model(int image) {
        this.image = image;



    }

    public int getImage() {
        return image;
    }

    public void setImage(int image) {
        this.image = image;
    }

}
