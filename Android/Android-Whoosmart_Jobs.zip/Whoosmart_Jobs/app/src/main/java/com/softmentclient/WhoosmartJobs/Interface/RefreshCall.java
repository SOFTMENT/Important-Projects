package com.softmentclient.WhoosmartJobs.Interface;

public interface RefreshCall {
    public void refresh();
}
