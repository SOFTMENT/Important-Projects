package com.svenska.YourMetroRecord.Interface;

public interface RefreshCall {
    public void refresh();
}
