package com.softmentclient.OrderLaundry.Interface;

public interface RefreshCall {
    public void refresh();
}
