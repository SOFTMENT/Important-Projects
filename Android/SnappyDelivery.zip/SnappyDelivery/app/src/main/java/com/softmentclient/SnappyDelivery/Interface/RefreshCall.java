package com.softmentclient.SnappyDelivery.Interface;

public interface RefreshCall {
    public void refresh();
}
