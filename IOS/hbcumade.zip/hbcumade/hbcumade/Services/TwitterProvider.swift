//
//  TwitterProvider.swift
//  hbcumade
//
//  Created by Vijay Rathore on 15/01/21.
//

import Foundation
import Firebase

struct TwitterProvider {
    static let provider = OAuthProvider(providerID: "twitter.com")
    
}
