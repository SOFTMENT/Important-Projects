//
//  FirebaseStoreManager.swift
//  hbcumade
//
//  Created by Vijay Rathore on 13/01/21.
//

import Firebase

struct FirebaseStoreManager {
    static let db = Firestore.firestore()
}

