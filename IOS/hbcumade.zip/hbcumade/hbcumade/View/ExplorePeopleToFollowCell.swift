//
//  ExplorePeopleToFollowCell.swift
//  hbcumade
//
//  Created by Vijay on 09/04/21.
//

import UIKit

class ExplorePeopleToFollowCell: UITableViewCell {
   
        
        
        @IBOutlet weak var follow: UILabel!
    @IBOutlet weak var information: UILabel!
        @IBOutlet weak var name: UILabel!
        @IBOutlet weak var profilePic: UIImageView!
        override func awakeFromNib() {
            super.awakeFromNib()
        }
        
        
    

}
