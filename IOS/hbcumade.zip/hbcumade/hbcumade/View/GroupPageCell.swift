import UIKit

class GroupPageCell : UITableViewCell {
    
    
    @IBOutlet weak var viewProfileBtn: UILabel!
    @IBOutlet weak var status: UILabel!
    @IBOutlet weak var name: UILabel!
    @IBOutlet weak var profilePic: UIImageView!
    override func awakeFromNib() {
        super.awakeFromNib()
    }
    
    
}


