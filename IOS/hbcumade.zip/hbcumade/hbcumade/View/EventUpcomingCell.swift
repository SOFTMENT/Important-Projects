//
//  EventUpcomingCell.swift
//  hbcumade
//
//  Created by Vijay on 09/04/21.
//

import UIKit

class EventUpcomingCell : UITableViewCell {
    
    
    
    
    @IBOutlet weak var date: UILabel!
   
    @IBOutlet weak var register: UILabel!
    
    
    @IBOutlet weak var status: UILabel!
    @IBOutlet weak var name: UILabel!
    @IBOutlet weak var profilePic: UIImageView!
    
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
    }
    
    
}
