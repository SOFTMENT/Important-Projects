//
//  DirectoryPageCell.swift
//  hbcumade
//
//  Created by Vijay Rathore on 28/01/21.
//

import UIKit

class NetworkPageCell : UITableViewCell {
    
    
    @IBOutlet weak var viewProfileBtn: UILabel!
    @IBOutlet weak var status: UILabel!
    @IBOutlet weak var name: UILabel!
    @IBOutlet weak var profilePic: UIImageView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
    }
    
    
}


