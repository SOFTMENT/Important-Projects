//
//  ExploreFindGroupCell.swift
//  hbcumade
//
//  Created by Vijay on 09/04/21.
//

import UIKit


class ExploreFindGroupCell : UITableViewCell {
    
    
    @IBOutlet weak var viewProfileBtn: UILabel!
    @IBOutlet weak var status: UILabel!
    @IBOutlet weak var name: UILabel!
    @IBOutlet weak var profilePic: UIImageView!
    override func awakeFromNib() {
        super.awakeFromNib()
    }
    
    
}
