
import Foundation

class Network : NSObject, Codable{
    var name : String?
    var status : String?
    var image : String?


    init(name : String, status : String, image : String) {
        self.name = name
        self.status = status
        self.image = image
        
    }
}


