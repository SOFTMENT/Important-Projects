//
//  User.swift
//  hbcumade
//
//  Created by Vijay Rathore on 17/01/21.
//

import Foundation
import FirebaseFirestoreSwift
import Firebase



class Comment : NSObject, Codable{
    
    var commentID : String?
    var uid : String?
    var name : String?
    var image : String?
    var classification : String?
    var commentText : String?
    var commentAt : Date?
    var commentLike : Int?
    var commentCount : Int?
    var school : String?

    
   
    static var comment : Comment?
    static var sharedInstance : Comment {
        set(commentData) {
            self.comment = commentData
        }
        get {
            return comment!
        }
    }
    
    private override init() {}


}


