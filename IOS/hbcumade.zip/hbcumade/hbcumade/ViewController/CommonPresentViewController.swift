//
//  CommonPresentViewController.swift
//  hbcumade
//
//  Created by Vijay on 30/03/21.
//

import UIKit

class CommonPresentViewController : BaseViewController, UINavigationControllerDelegate{
    
    override func viewDidLoad() {
        
    }
    
   
    
    override func viewDidAppear(_ animated: Bool) {
    
//        tabBarController?.selectedIndex = Constants.previousSelectedTabIndex
//
//        let tabBarItems = tabBarController?.tabBar.items![Constants.previousSelectedTabIndex]
//
//        if Constants.previousSelectedTabIndex  == 0{
//            tabBarItems!.selectedImage = UIImage(named: "icons8-home-100")?.withRenderingMode(.alwaysOriginal)
//        }
//       else if Constants.previousSelectedTabIndex  == 1{
//        tabBarItems!.selectedImage = UIImage(named: "icons8-calendar-100")?.withRenderingMode(.alwaysOriginal)
//        }
//       else if Constants.previousSelectedTabIndex  == 2{
//        tabBarItems!.selectedImage = UIImage(named: "icons8-plus-math-96")?.withRenderingMode(.alwaysOriginal)
//        }
//        else if Constants.previousSelectedTabIndex  == 3{
//            tabBarItems!.selectedImage = UIImage(named: "icons8-microphone-100")?.withRenderingMode(.alwaysOriginal)
//        }
//
//
//
//        let tabBarItems1 = tabBarController?.tabBar.items![4]
//        tabBarItems1!.image = UIImage(named: "icons8-user-96-2")?.withRenderingMode(.alwaysOriginal)
    }
}
