import UIKit
import SDWebImage

protocol MenuButtonClickedDelegate {
    func menuButtonClicked(_ imageview : UIImageView)
}

class TopBarViewController: UIViewController {
  
    
    var delegate : MenuButtonClickedDelegate?
    @IBOutlet weak var searchBtn: UIView!
//    @IBOutlet weak var searchTextField: UITextField!
    @IBOutlet weak var menuBtn: UIImageView!
    override func viewDidLoad() {
         
        let menuGesture = UITapGestureRecognizer(target: self, action: #selector(menuBtnClicked(tapGestureRecognizer:)))
        menuBtn.isUserInteractionEnabled = true
        menuBtn.addGestureRecognizer(menuGesture)
//        self.searchTextField.setLeftPaddingPoints(10)
//        self.searchTextField.setRightPaddingPoints(10)
//        self.searchTextField.attributedPlaceholder = NSAttributedString(string: "Search...",
//                                     attributes: [NSAttributedString.Key.foregroundColor: UIColor.gray])
//
       
    }

    @objc func menuBtnClicked(tapGestureRecognizer : UITapGestureRecognizer) {
        let imageView = tapGestureRecognizer.view as! UIImageView
       
        delegate?.menuButtonClicked(imageView)
    }
    
    
   
}

