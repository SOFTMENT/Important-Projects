//
//  NetworkViewController.swift
//  hbcumade
//
//  Created by Vijay on 05/04/21.
//

import UIKit

class NetworkViewController: BaseViewController, UITableViewDelegate, UITableViewDataSource {

    @IBOutlet weak var directorySearchEditField: UITextField!
    @IBOutlet weak var tableViewHeight: NSLayoutConstraint!
    @IBOutlet weak var scrollView: UIScrollView!
    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var gridStack: UIStackView!
    @IBOutlet weak var addFilterBtn: UIButton!

    var networks = Array<Network>()
    override func viewDidLoad() {
        
        
        directorySearchEditField.attributedPlaceholder = NSAttributedString(string: "Search...",
                                     attributes: [NSAttributedString.Key.foregroundColor: UIColor.darkGray])
        
        directorySearchEditField.setLeftPaddingPoints(10)
        directorySearchEditField.setRightPaddingPoints(10)
        tableView.delegate = self
        tableView.dataSource = self
        tableView.isScrollEnabled = false
   
        self.tableView.rowHeight = UITableView.automaticDimension
        self.tableView.estimatedRowHeight = 44
        
        //AddFilterButton
        addFilterBtn.layer.cornerRadius = 6
        
        
        
       networks.append(Network(name: "Vijay Rathore", status: "Mobile App Developer", image: "https://i.pravatar.cc/300"))
        networks.append(Network(name: "Manoj Kumar Verma", status: "Professional Logo Designer", image: "https://i.pravatar.cc/301"))
        networks.append(Network(name: "Vaibhav Sharma", status: "Businessman", image: "https://i.pravatar.cc/302"))
        networks.append(Network(name: "Akshay Munya", status: "Teacher", image: "https://i.pravatar.cc/303"))
        networks.append(Network(name: "Salman Khan", status: "Available", image: "https://i.pravatar.cc/304"))
        networks.append(Network(name: "Akshay Kumar", status: "can't talk whatsapp only", image: "https://i.pravatar.cc/305"))
        networks.append(Network(name: "Rajkumar Hirani", status: "Website Developer", image: "https://i.pravatar.cc/306"))
        networks.append(Network(name: "Shashikant Bharti", status: "Artist", image: "https://i.pravatar.cc/307"))
        networks.append(Network(name: "Amit Giri", status: "Singer", image: "https://i.pravatar.cc/308"))
        networks.append(Network(name: "Ajay Rathore", status: "Battery about to die", image: "https://i.pravatar.cc/309"))
        networks.append(Network(name: "Vermaak Petrus", status: "Professional Logo Designer", image: "https://i.pravatar.cc/310"))
        networks.append(Network(name: "Krishna Yadav", status: "Can't talk whatsapp only", image: "https://i.pravatar.cc/311"))
        networks.append(Network(name: "Anmol Pandey", status: "YouTuber", image: "https://i.pravatar.cc/312"))
        networks.append(Network(name: "Naresh Dewra", status: "Freelancer", image: "https://i.pravatar.cc/313"))
        networks.append(Network(name: "Manyank Gothi", status: "Website Developer", image: "https://i.pravatar.cc/314"))
        networks.append(Network(name: "Sanju Samson", status: "Hardware Expert", image: "https://i.pravatar.cc/315"))
        
      
      
        
    }
    

    override func viewDidAppear(_ animated: Bool) {
        self.tableView.reloadData()
        self.tableView.layoutIfNeeded()
        self.tableViewHeight.constant = CGFloat(105 * networks.count)
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
       
        return networks.count
    }
 
  
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
       
        
        if let cell = tableView.dequeueReusableCell(withIdentifier: "networkcell", for: indexPath) as? NetworkPageCell {
           
            let directory = self.networks[indexPath.row]
           
            cell.profilePic.makeRounded()
            cell.name.text = directory.name
            cell.status.text = directory.status
            if directory.image != "" {
                
                cell.profilePic.sd_setImage(with: URL(string: directory.image!), placeholderImage:UIImage(named: "profile-user"))
                cell.profilePic.sd_setImage(with: URL(string: directory.image!), placeholderImage: UIImage(named: "profile-user"), options: .refreshCached) { (uiimgae, error, cache, url) in
                    
                }
            }
          
          
            return cell
            
        }
       
        return NetworkPageCell()
        
    }
    
    
    
    
}
