//
//  TabBarController.swift
//  hbcumade
//
//  Created by Vijay on 23/03/21.
//

import UIKit


class TabBarController: UITabBarController, UITabBarControllerDelegate {

    
    
    
    var tabBarItems = UITabBarItem()

    let slideVC = OverlayView()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.delegate  = self
   

        let selectedImage1 = UIImage(named: "icons8-home-100-3")?.withRenderingMode(.alwaysOriginal)
        let deSelectedImage1 = UIImage(named: "icons8-home-100")?.withRenderingMode(.alwaysOriginal)
        tabBarItems = self.tabBar.items![0]
        tabBarItems.image = deSelectedImage1
        tabBarItems.selectedImage = selectedImage1
        
        let selectedImage2 = UIImage(named: "icons8-calendar-100-2")?.withRenderingMode(.alwaysOriginal)
        let deSelectedImage2 = UIImage(named: "icons8-calendar-100")?.withRenderingMode(.alwaysOriginal)
        tabBarItems = self.tabBar.items![1]
        tabBarItems.image = deSelectedImage2
        tabBarItems.selectedImage = selectedImage2
        
        let selectedImage3 = UIImage(named: "icons8-plus-math-96-2")?.withRenderingMode(.alwaysOriginal)
        let deSelectedImage3 = UIImage(named: "icons8-plus-math-96")?.withRenderingMode(.alwaysOriginal)
        tabBarItems = self.tabBar.items![2]
        tabBarItems.image = deSelectedImage3
        tabBarItems.selectedImage = selectedImage3
        
        
        let selectedImage11 = UIImage(named: "icons8-microphone-100-2")?.withRenderingMode(.alwaysOriginal)
        let deSelectedImage11 = UIImage(named: "icons8-microphone-100")?.withRenderingMode(.alwaysOriginal)
        tabBarItems = self.tabBar.items![3]
        tabBarItems.image = deSelectedImage11
        tabBarItems.selectedImage = selectedImage11
        
        
        let selectedImage4 = UIImage(named: "icons8-user-96-2")?.withRenderingMode(.alwaysOriginal)
        let deSelectedImage4 = UIImage(named: "icons8-user-96")?.withRenderingMode(.alwaysOriginal)
        tabBarItems = self.tabBar.items![4]
        tabBarItems.image = deSelectedImage4
        tabBarItems.selectedImage = selectedImage4
       
        Constants.tabBarHeight = self.tabBarController?.tabBar.frame.height ?? 49.0
        Constants.safeAreaHeight = self.view.safeAreaFrame
   
    }
    
    override func tabBar(_ tabBar: UITabBar, didSelect item: UITabBarItem) {
        if item == self.tabBar.items![4] {
            
    
            let vc =  self.viewControllers![4]
                if let nav = vc as? UINavigationController  {
                   
                    if !(nav.topViewController is CommonPresentViewController) {
                        if !(Constants.previousSelectedTabIndex == 4){
                            nav.popViewController(animated: false)
                        }
                       
                    }
                    
                }
            
            showOverlayView()
            
        }
        else if item == self.tabBar.items![3] {
            item.selectedImage = UIImage(named: "icons8-microphone-100-2")?.withRenderingMode(.alwaysOriginal)
            Constants.previousSelectedTabIndex = 3
            
        }
        else if item == self.tabBar.items![2] {
            let vc =  self.viewControllers![2]
                if let nav = vc as? UINavigationController  {
                   
                    if !(nav.topViewController is CommonPresentViewController2) {
                        if !(Constants.previousSelectedTabIndex == 2){
                            nav.popViewController(animated: false)
                        }
                       
                    }
                    
                }
            
            showOverlayView()
        }
        else if item == self.tabBar.items![1] {
            item.selectedImage = UIImage(named: "icons8-calendar-100-2")?.withRenderingMode(.alwaysOriginal)
            Constants.previousSelectedTabIndex = 1
        }
        else if item == self.tabBar.items![0] {
            item.selectedImage = UIImage(named: "icons8-home-100-3")?.withRenderingMode(.alwaysOriginal)
            Constants.previousSelectedTabIndex = 0
        }
    }
    
    
     func showOverlayView() {
        
        slideVC.modalPresentationStyle = .custom
        slideVC.transitioningDelegate = self
        self.present(slideVC, animated: true, completion: nil)
        self.selectedIndex = 0
        
    }
    
   
}



extension TabBarController: UIViewControllerTransitioningDelegate {
    func presentationController(forPresented presented: UIViewController, presenting: UIViewController?, source: UIViewController) -> UIPresentationController? {
            PresentationController(presentedViewController: presented, presenting: presenting)
    }
    
    
    

}
      

