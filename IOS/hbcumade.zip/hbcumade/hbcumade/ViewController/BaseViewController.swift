import UIKit
import StoreKit

class BaseViewController: UIViewController, MenuButtonClickedDelegate, SlideMenuDelegate {
  
    func slideMenuItemSelectedAtIndex(_ name: String) {
        
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    func menuButtonClicked(_ sender  : UIImageView) {
        print("SIDE MENU LOAD")
        if (sender.tag == 10)
        {
            
            sender.tag = 0;
            
            let viewMenuBack : UIView = view.subviews.last!
            
            UIView.animate(withDuration: 0.3, animations: { () -> Void in
                var frameMenu : CGRect = viewMenuBack.frame
                frameMenu.origin.x = -1 * UIScreen.main.bounds.size.width
                viewMenuBack.frame = frameMenu
                viewMenuBack.layoutIfNeeded()
                viewMenuBack.backgroundColor = UIColor.clear
                }, completion: { (finished) -> Void in
                    viewMenuBack.removeFromSuperview()
            })
            
            return
        }

  
        sender.isUserInteractionEnabled = false
        sender.tag = 10

        let menuVC : MenuViewController = self.storyboard!.instantiateViewController(withIdentifier: "MenuViewController") as! MenuViewController
        menuVC.btnMenu = sender
        menuVC.delegate = self
        self.view.addSubview(menuVC.view)
        self.addChild(menuVC)
        menuVC.view.layoutIfNeeded()
       let height = view.window?.windowScene?.statusBarManager?.statusBarFrame.height ?? 0
        let yh = 70 + height
        
        print(height)
     
        menuVC.view.frame=CGRect(x: 0 - UIScreen.main.bounds.size.width, y: yh, width: UIScreen.main.bounds.size.width, height: UIScreen.main.bounds.size.height - height);

        UIView.animate(withDuration: 0.3, animations: { () -> Void in
            menuVC.view.frame=CGRect(x: 0, y: yh, width: UIScreen.main.bounds.size.width, height: UIScreen.main.bounds.size.height - height);
            sender.isUserInteractionEnabled  = true
            }, completion:nil)

    }
    
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "topbarseg" {
            if let topbar = segue.destination as? TopBarViewController {
            topbar.delegate = self
            }
        }
    }
   

    
}
