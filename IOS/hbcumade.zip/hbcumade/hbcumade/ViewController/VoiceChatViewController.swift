//
//  VoiceChatViewController.swift
//  hbcumade
//
//  Created by Vijay on 18/04/21.
//

import UIKit

class VoiceChatViewController: UIInputViewController {
    override func viewDidLoad() {
        
    }
}
