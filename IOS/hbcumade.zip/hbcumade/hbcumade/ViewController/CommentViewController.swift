//
//  CommentViewController.swift
//  hbcumade
//
//  Created by Vijay Rathore on 27/01/21.
//

import UIKit
import Firebase

class CommentViewController: UIViewController, UITextViewDelegate, UITableViewDataSource, UITableViewDelegate {
    
    
    @IBOutlet weak var bottomViewCons: NSLayoutConstraint!
    @IBOutlet weak var postBtn: UIImageView!
    @IBOutlet weak var myEditField: UITextView!
    @IBOutlet weak var backBtn: UIImageView!
    @IBOutlet weak var tableView: UITableView!
    var reg : ListenerRegistration?
    var comments = Array<Comment>()
    var cUid  = ""
    
    override func viewDidLoad() {
        
        cUid = Auth.auth().currentUser!.uid
        myEditField.delegate = self
        myEditField.sizeToFit()
        myEditField.isScrollEnabled = false
        myEditField.backgroundColor = UIColor.white
        self.myEditField.contentInset = UIEdgeInsets(top: 5 , left: 10, bottom: 5, right: 10);
        self.myEditField.becomeFirstResponder()
        
        tableView.delegate = self
        tableView.dataSource = self
     
        
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillShow), name: UIResponder.keyboardWillShowNotification, object: nil)
              
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillHide), name: UIResponder.keyboardWillHideNotification, object: nil)
              
        let tap = UITapGestureRecognizer(target: self, action: #selector(dismissKeyboard))
                tap.cancelsTouchesInView = true
              view.addGestureRecognizer(tap)
        
        
        //POSTBUTTON
        postBtn.isUserInteractionEnabled = true
        postBtn.addGestureRecognizer(UITapGestureRecognizer(target: self, action: #selector(addNewCommnet)))
        
        //POSTBUTTON
        backBtn.isUserInteractionEnabled = true
        backBtn.addGestureRecognizer(UITapGestureRecognizer(target: self, action: #selector(backBtnTapped)))
        
        getAllComment()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        tableView.rowHeight = UITableView.automaticDimension
        tableView.estimatedRowHeight = 44
    }
    
    @objc func backBtnTapped() {
        self.dismiss(animated: true, completion: nil)
    }
    
    @objc func addNewCommnet() {
        
        let commentText  = myEditField.text.trimmingCharacters(in: .whitespacesAndNewlines)
        if commentText != "" {
            let ref =  FirebaseStoreManager.db.collection("AllPosts").document(Constants.postID).collection("Comments")
                    let id = ref.document().documentID
            let commentData = ["commentID" : id, "uid" : cUid, "name" : UserData.data?.name ?? "Default", "school" : UserData.data?.school ?? "","classification" : "Alumni","commentAt" : Date() , "commentLike" : 0 , "commentCount" : 0 , "image" : UserData.data?.profile ?? "", "commentText" : commentText] as [String : Any]
            
            
                    ref.document(id).setData(commentData) { (err) in
                        if err != nil {
                            print(err!.localizedDescription)
                        }
                        else {
                            FirebaseStoreManager.db.collection("AllPosts").document(Constants.postID).getDocument { (snapshot, error) in
                                if error != nil {
                                    self.showError(error!.localizedDescription)
                                   
                                }
                                else {
                                    
                                    if let post = try? snapshot?.data(as: Post.self) {
                                        FirebaseStoreManager.db.collection("AllPosts").document(Constants.postID).updateData(["commentCount" : (post.commentCount! + 1)])
                                        
                                    }
                            }
                            self.myEditField.text = ""
                            self.showToast(message: "Comment has been added")
                        }
                    }
        }
    }
}
    
    func getAllComment() {
        
        reg =  FirebaseStoreManager.db.collection("AllPosts").document(Constants.postID).collection("Comments").order(by: "commentAt",descending: true).limit(toLast: 100).addSnapshotListener(includeMetadataChanges: true) { (snapshot, error) in
            if error != nil {
                self.showError(error!.localizedDescription)
            }
            else {
                
                if let snapshot = snapshot {
                    if !(snapshot.metadata.hasPendingWrites) {
                        let documents = snapshot.documents
                        self.comments.removeAll()
                        
                        self.comments = documents.map({ (snapshot) -> Comment in
                        let comment = try? snapshot.data(as: Comment.self)
                        return comment!
                            
                        })
                        
                        self.comments.reverse()
                        self.tableView.reloadData()
                        if self.comments.count > 0 {
                            self.scrollToBottom()
                        }
                    
                        
                    }
                }
              
              
            }
        }
    }
    
    func scrollToBottom(){
        DispatchQueue.main.async {
            let indexPath = IndexPath(row: self.comments.count-1, section: 0)
            self.tableView.scrollToRow(at: indexPath, at: .bottom, animated: true)
        }
    }
    
 @objc func keyboardWillShow(notify: NSNotification) {
      
     if let keyboardSize = (notify.userInfo?[UIResponder.keyboardFrameEndUserInfoKey] as? NSValue)?.cgRectValue {
        var bottomPadding = CGFloat(0)
        if #available(iOS 11.0, *) {
            let window = UIApplication.shared.windows[0]
            bottomPadding = window.safeAreaInsets.bottom
            
            
        }
         bottomViewCons.constant  = keyboardSize.height - bottomPadding
         UIView.animate(withDuration: 0.5) {
            self.view.layoutIfNeeded()
         }
          
         
      }
  }
  
  @objc func keyboardWillHide(notify: NSNotification) {
      
      bottomViewCons.constant  = 0
      UIView.animate(withDuration: 0.5) {
                   self.view.layoutIfNeeded()
     }
     
  }
    
    @objc func dismissKeyboard() {
        view.endEditing(true)
     }
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return comments.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        if let cell = tableView.dequeueReusableCell(withIdentifier: "commentCell", for: indexPath) as? CommentPageTableCell {
            
            let comment = comments[indexPath.row]
            if comment.image != "" {
                cell.prrofilePic.sd_setImage(with: URL(string: comment.image!), placeholderImage: UIImage(named: "profile-user"))
            }
           
            cell.name.text = comment.name
            cell.commentText.text = comment.commentText!
            cell.commentCount.text = String.init(comment.commentCount!)
            cell.likeCount.text = String.init(comment.commentLike!)
            
            if (comment.classification?.caseInsensitiveCompare("Alumni") == .orderedSame) {
                cell.classificationImage.image = UIImage(named: "icons8-graduation-cap-50")
            }
            else {
                cell.classificationImage.image = UIImage(named: "icons8-reading-50")
            }
            
            cell.universityName.text = comment.school
            
       
            
            return cell
        }
        
        return CommentPageTableCell()
    }
}
