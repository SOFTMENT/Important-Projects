//
//  TempView.swift
//  hbcumade
//
//  Created by Vijay on 10/04/21.
//

import UIKit

class TempView: BaseViewController {
    override func viewDidLoad() {
        
    }
    override func viewWillAppear(_ animated: Bool) {
        performSegue(withIdentifier: "eventSeg", sender: nil)
    }
}
