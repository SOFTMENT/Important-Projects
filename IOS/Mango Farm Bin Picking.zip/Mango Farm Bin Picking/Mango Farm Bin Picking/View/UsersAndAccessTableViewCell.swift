//
//  UsersAndAccessTableViewCell.swift
//  Mango Farm Bin Picking
//
//  Created by Vijay on 20/04/21.
//

import UIKit

class UserAndAccessTableViewCell: UITableViewCell {
    
    
    @IBOutlet weak var name: UILabel!
    @IBOutlet weak var warehouse: UILabel!
    @IBOutlet weak var email: UILabel!
    @IBOutlet weak var removeBtn: UIButton!
    
    
    override class func awakeFromNib() {
        
    }
}
