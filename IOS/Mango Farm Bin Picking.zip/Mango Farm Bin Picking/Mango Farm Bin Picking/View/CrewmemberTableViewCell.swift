//
//  CrewmemberTableViewCell.swift
//  Mango Farm Bin Picking
//
//  Created by Vijay on 19/04/21.
//

import UIKit

class CrewmemberTableViewCell: UITableViewCell {
    
    @IBOutlet weak var download: UIButton!
    @IBOutlet weak var wareHouseName: UILabel!
    @IBOutlet weak var email: UILabel!
    
    @IBOutlet weak var name: UILabel!
    
    override class func awakeFromNib() {
        super.awakeFromNib()
    }
    
    
}
