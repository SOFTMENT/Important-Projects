//
//  HomeNavigationController.swift
//  Mango Farm Bin Picking
//
//  Created by Vijay on 15/04/21.
//

import UIKit

class HomeNavigationController: UINavigationController {
    override func viewDidLoad() {
        
    }
}
